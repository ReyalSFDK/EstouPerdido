<?php
$Jname = '<font color="#3c9"><b>'.$_COOKIE["Jname"].'</b></font>';
$Bname = '<font color="#c39"><b>'.$_COOKIE["Bname"].'</b></font>';
$Player = '<font color="#39c"><b>Você</b></font>';


$airplane_1_p1 = "Você está dentro de um avião comercial voltando de uma viagem de férias com seus dois amigos. Você está sentado na fileira da direita, na poltrona bem do lado da janela e seus dois amigos estão sentados à sua esquerda: $Jname bem do seu lado e $Bnam3 na última poltrona.";
$airplane_1_p2 = "Olhando pela janela do avião dá para ver o tanto que o avião está longe do chão. No momento ele sobrevoa o oceano, bem perto das nuvens, que desmancham ao tocar na asa, e próximo a pássaros que voam em bando. Uma cena de encher os olhos.";
$airplane_1_p3 = "Você olha para o outro lado e vê seus dois amigos conversando, eles parecem muitos felizes. Você não participa da conversa, $Bname ri bastante e $Jname fica olhando várias vezes para você, com uma cara de preocupado. Em uma dessas olhadas ele para e te pergunta:";
$airplane_1_j1 = "Cara, você está se sentindo bem?";
$airplane_notify_1 = " $Jname se preocupa com você!";
$airplane_1_p4 = "Nesse momento $Bname para de rir e os dois te olham atentamente esperando a sua resposta:";
///Escolhas
$airplane_1_c1 = "Dizer que está bem.";
$airplane_1_c2 = "Reclamar por deixar de fora da conversa.";

///Dizer que esta bem (airplane_1_c1)
$airplane_1_1_vc1 = "Estou bem sim, obrigado por perguntar. Só estou incomodado com uma coisa aqui...";
$airplane_1_1_j1 = "Ah cara, o que que te incomoda? Posso ajudar? Você sabe que pode contar comigo à qualquer hora né?";
$airplane_1_1_p1 = "Você está mesmo incomodado, talvez seja aquela cena da menina que você é apaixonado conversando tão intimamente com o seu melhor amigo. Você também sente uma outra sensação, uma do tipo bem estranha. Você sente que algo inesperado vai acontecer ali, uma intuição. Até você acha estranho aquilo e sente receio de falar, pois acha que vão te chamar de maluco...";
///Escolhas
$airplane_1_1_c1 = "Falar da conversa dele com $Bname";
$airplane_1_1_c2 = "Falar do pressentimento que você tem";
$airplane_1_1_c3 = "Não contar nada";

/// Reclamar por deixar(airplane_1_c2)
$airplane_1_2_vc1 = "Ah, agora vocês perceberam que eu estou aqui né!";
$airplane_1_2_j1 =  "Que isso cara, calma. Só estavamos...";
$airplane_1_2_vc2 =  "Não precisa falar mais nada! Se eu soubesse que iria ficar sobrando...";
$airplane_1_2_b1 = "Calma aew cara! O que você tem? Você não é assim... está acontecendo alguma coisa?";
$airplane_1_2_p1 = "Você começa a ficar com calafrios, a suar frio e suas mãos tremem por alguns segundos, mas logo depois esses sintomas passam. Algo misteriosamente começa a preocupar você, uma sensação ruim toma conta de você. Algo que nunca aconteceu antes. Parece coisa de louco, e, talvez seus amigos ririam disso.";
///Escolhas
$airplane_1_2_c1 = "Não contar nada e admitir o ciúmes.";
$airplane_1_2_c2 = "Contar sobre o que você sentiu.";
$airplane_1_2_c3 = "Dizer que não é da conta deles.";

/// Falar da conversa (airplane_1_1_c1)
$airplane_1_1_1_vc1 = "Nada cara... Só não queria atrapalhar a conversinha de vocês dois ai...";
$airplane_1_1_1_j1 = "Xiii, lá vem ele de ciuminhos de novo...";
$airplane_1_1_1_b1 = "Ei! Mas que conversa é essa?";
$airplane_notify_2 = "$Bname notou seus ciúmes.";
$airplane_1_1_1_j2 = "Não, não é nada sobre você, - ele olha para você e pisca um olho - não se preocupe.";
$airplane_1_1_1_b2 ="Não gosto desse tom da conversa de vocês...";
$airplane_1_1_1_vc2 = "Quer saber? Vou dormir que eu ganho mais, me acordem na hora de desembarcar.";
$airplane_1_1_1_b3 = "Do jeito que você <i>tá</i> estranho, te deixo aí pra te mandarem de volta hahaha (Risos).";
$airplane_1_1_1_vc3 = "Haha, engraçada...";
$airplane_1_1_1_j3 = "Dorme bem cara!";
$airplane_1_1_1_p1 = "Você então encosta cabeça na poltrona e vira a cabeça para a janela do avião, aquela paisagem vai te relaxando e rapidamente você cai no sono.";
    
//Falar do presentimento (airplane_1_1_c2)(airplane_1_2_c2)
$airplane_1_1_2_vc1 = "Não sei bem o que é. Eu sinto como se alguma coisa de ruim estivesse para acontecer...";
$airplane_1_1_2_j1 = "Como assim cara? Estamos em um avião! Eu como um ex militar te garanto que é o meio de transporte mais seguro que existe! Acho que isso é mania de detetive.";
$airplane_1_1_2_b1 = "Cara, deixa de paranóia. Relaxa ai...";
$airplane_1_1_2_p1 = "Seus amigos começam a rir.";
$airplane_1_1_2_vc2 = "Qual o motivo da graça?";
$airplane_1_1_2_b2 = "Nada... Só tenta relaxar um pouco. Não vai acontecer nada. É só... - ela segura o riso -<em> medo.</em> ";
$airplane_1_1_2_vc3 = "Acho que é o melhor que eu faço... me acorde na hora de desembarcar.";
$airplane_1_1_2_b3 = "Ok, não se procupe!";
$airplane_1_1_2_p2 = "Você então encosta cabeça na poltrona e vira a cabeça para a janela do avião, aquela paisagem vai te relaxando e rapidamente você cai no sono.";

// Nao contar nada (airplane_1_1_c3)
$airplane_1_1_3_vc1 = "Não é nada, é besteira minha.";
$airplane_1_1_3_b1 = "Como sempre né?";
$airplane_1_1_3_vc2 = "Não perde uma eim...";
$airplane_1_1_3_j1 = "Tudo bem cara, se você diz que não é nada.";
$airplane_1_1_3_b2 = "Tenta relaxar um pouco ai, você parece mais estranho que o normal.";
$airplane_1_1_3_vc3 = "Agora falou algo de útil! Vou dormir, me acordem na hora do desembarque!";
$airplane_1_1_3_p1 = "Você então encosta cabeça na poltrona e vira a cabeça para a janela do avião, aquela paisagem vai te relaxando e rapidamente você cai no sono.";


// Adimitit os ciumes
$airplane_1_2_1_vc1 = "Não é nada de mais cara! Apenas fiquei com um pouco de ciúmes, admito.";
$airplane_1_2_1_j1 = "Não precisa se desculpar cara, acho que tenho um pouco de culpa nisso também.";
$airplane_1_2_1_b1 = "Concordo com $Jname, a culpa é dele mesmo!";
$airplane_1_2_1_j2 = "Cala boca $Bname, você não entra em nada.";
$airplane_notify_3 = "Todos se lembrarão disso.";
$airplane_1_2_1_p1 = "Naquele momento todos começam a rir, como se estivessem ainda nas férias.";
$airplane_1_2_1_j3 = "Fazemos uma bela equipe, espero que nunca nos separamos!";
$airplane_1_2_1_b2 = "Vocês são minha familia, o que dizer de $Jname? Mal conheço e já considero pakas!";
$airplane_1_2_1_j4 = "Graças a nosso amigo em comum pudemos nos conhecer!";
$airplane_1_2_1_b3 = "Tem razão, ele é um gênio!";
$airplane_1_2_1_vc2 = "Obrigado, obrigado... Estou um pouco cansado, vou dormir um pouco... Só não me deixem no avião dormindo eim!";
$airplane_1_2_1_j5 = "Pode deixar!";
$airplane_1_2_1_p2 =  "Você então encosta cabeça na poltrona e vira a cabeça para a janela do avião, aquela paisagem vai te relaxando e rapidamente você cai no sono.";

// Dizer q nao e da conta deles (airplane_1_2_c3 )
$airplane_1_2_2_vc1 = "Não é da conta de vocês.";
$airplane_1_2_2_j1 = "Ui, nossa, que grosseiro. Vai me morder agora ou depois?";
$airplane_1_2_2_b1 = "Deixa ele se acalmar $Jname. Melhor não provocar o bebê bravo!";
$airplane_notify_4 = "Eles se lembrarão disso.";
$airplane_1_2_2_p1 = "No momento os dois riem.";
$airplane_1_2_2_vc2 = "Melhor eu dormir, já que não tão nem aí mesmo...";
$airplane_1_2_2_b2 = "Ei, não fica assim!";
$airplane_1_2_2_j2 = "O que nós fizemos?";
$airplane_1_2_2_vc3 = "Nada, esqueçam...";
$airplane_1_2_2_p2 =  "Você então encosta cabeça na poltrona e vira a cabeça para a janela do avião, aquela paisagem vai te relaxando e rapidamente você cai no sono.";

//Sonho 
$sleep = "Dormir";
$dream1_1 = "Você está um lugar bastante escuro, não dá para enxergar nada em qualquer direção que você olhe.";
$dream1_2 = "Você até tenta andar em busca de alguma saída mas é como se não houvesse fim naquele lugar.";
$dream1_3 = "Você tomba em algo que impede a sua passagem, você começa a esticar a sua mão com o fim de descobrir o que te fez parar <b> - parece ser uma parede -.</b>";
$dream1_4 = "Ainda está muito escuro, mas de repente, a parede começa a surgir um pequeno feixe de luz vermelha na altura dos seus ombros. ";
$dream1_5 = "A luz vai ficando cada vez mais forte e vai se tornando um desenho. Depois de alguns segundos o desenho se completa. <b>É um tubarão.</b>";
$dream1_6 = " Você então sente aquele desenho te chamar, vozes ecoam na sua mente, e como em uma ação involuntária, você estica a mão lentamente até tocar o desenho. ";
$dream1_7 = "Logo outra luz aparece cortando bem no meio daquela parede na vertical, do chão até lá no alto, e vai se intensificando, a parede parece abrir para os lados, como se houvesse uma passagem secreta. ";
$dream1_8 = 'Ela se abre aos poucos e entre a brecha dá para ver uma floresta linda, arvores altas e tons de verde hipnotizantes <font color="#0f0">- um verdadeiro paraíso -.</font>';
$dream1_9 = '<font color="#bd1010">Você começa a escutar um barulho atrás de você.</font>';
$dream1_10 = "Olhando para trás não dá para ver o que é, é muito escuro ainda e a luz que vem da passagem só é capaz de iluminar um pedaço daquele lugar.";
$dream1_11 = "Você se vira para trás e O barulho vai ficando mais alto.";
$dream1_12 = 'De repente... <font color="#bd1010"><b>Três olhos cheios de sangue aparecem flutuando na sua frente!</b> </font> Um rosnado ecoa no local, uma neblina densa aparece de repente no ambiente. Um cenário que deixaria qualquer um com medo.';
$dream1_13 = "Os olhos vão se aproximando de você... Mas ao tocarem na luz que sai da passagem eles somem do nada, junto com a neblina e toda aquela cena de terror.";
$dream1_14 = '<font color="#bd1010"><b>Você ouve gritos agora</b></font>';
$dream1_15 = "Você começa a tossir por causa de uma fumaça, ela vem da passagem que se abriu.";
$dream1_16 = 'Virando para ela você vê um cenário de destruição. Aquela paisagem que ali estava antes agora está queimando em chamas e virando cinzas, um verdadeiro <font color="#bd1010">inferno.</font>';
$dream1_17 = " Máquinas gigantes vão abrindo caminho entre as arvores queimadas, todas elas tem uma marca em vermelho, estão longe mas dá para ver que nitidamente é um desenho de um <b>tubarão.</b>";
$dream1_18 = " Elas estão sendo escoltadas por homens: Eles estão vestindo uma armadura hidráulica e equipados com lança-chamas - parecem retirados de um Vídeo Game -.";
$dream1_19 = "Parecem ter algumas pessoas lutando contra eles, mas são facilmente massacradas. ";
$dream1_20 = "Alguns tentam fugir queimando em chamas, uma cena pertubadora.";
$dream1_21 = 'Você até consegue sentir a dor das pessoas, seu corpo começa a <b>surgir <font color="#bd1010">queimaduras</font> sua pele começa a cair e a dor é agonizante</b>.';
$dream1_22 = " Você cai no chão se debatendo com aquela dor alucinante e desmaia.";
$dream1_c1 = "Acordar";

$airplane_2_p1 = "Você então acorda, abrindo lentamente os olhos você vê a janela com vista para o oceano e uma ilha. Um pouco tonto, seus sentidos vão voltando aos poucos, e, como em um reflexo você olha para seus dois braços em busca de algum ferimento - não há nada, nem um arranhão -.";
$airplane_2_p2 = "Você respira aliviado, sem entender nada e já parcialmente recuperado você comenta, virando a cabeça para a sua esquerda:";
$airplane_2_vc1 = "Gente, vocês não vão acreditar...";
$airplane_2_p3 = 'Seus amigos estão com máscaras de ar no rosto e os cintos apertados.<font color="#bd1010">Uma aeromoça é arremessada de uma ponta a outra do avião.</font> Com seus sentidos recuperados você sente o avião tremer muito e consegue ouvir as pessoas gritarem apavoradas.';
$airplane_2_p4 = "Há um buraco enorme do casco do avião. Há pessoas que são arrastadas para aquele buraco e entram em queda livre no céu. As malas dos compartimentos voam sobre o interior do avião. Você está sem seus cintos e começa a sentir <b>dificuldades para respirar.</b>";
$airplane_2_c1 = "Apertar os Cintos";
$airplane_2_c2 = "Colocar mascara de oxigênio";

$airplane_2_1_p1 = "Você tenta puxar os cintos de segurança da poltrona do avião, mas parece está emperrado em alguma coisa, o avião começa a se inclinar para frente e você é jogado para a poltrona da frente com muita força.";

$airplane_2_2_p1 = "Você pega a máscara de oxigênio bem a sua frente e coloca sobre seu rosto. Você vai respirando o oxigênio lentamente, quando o avião se inclina para frente e você é arremessado em direção a potrona da frente.";

$airplane_3_p1 = "Você vai levantando e apoia as suas costas na poltrona, ficando de frente para seus amigos, eles viram a cena e choram muito, tentam gritar mas os gritos são abafados pelas mascaras sobre seus rostos.";
$airplane_3_p2 = "$Jname estica a mão dele, parece que ele quer que você a segure. O avião balança muito.";
$airplane_3_c1 = "Segurar a mão dele";
        

?>




