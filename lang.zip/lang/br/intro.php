<?php
$intro_InputNameJ = "Digite o nome do seu melhor amigo:";
$Jname = "João";
$intro_InputNameB = "Digite o nome da sua melhor amiga:";
$Bname = "Beatriz";
$intro_Confirm = "Confirmar";
?>